package co.prachi;



	abstract class Compartment {
		public abstract String notice();
	}

	class FirstClass extends Compartment {

		@Override
		public String notice() {
			// TODO Auto-generated method stub
			return "You are in First Class Compartment";
		}
		
	}

	class Ladies extends Compartment {

		@Override
		public String notice() {
			// TODO Auto-generated method stub
			return "You are in Ladies Compartment";
		}
		
	}

	class General extends Compartment {

		@Override
		public String notice() {
			// TODO Auto-generated method stub
			return "You are in General Compartment";
		}
		
	}

	class Luggage extends Compartment {

		@Override
		public String notice() {
			// TODO Auto-generated method stub
			return "You are in Lugguage Compartment";
		}
		
	}




