package co.prachi;




import java.time.LocalDate;
import java.util.Date;

public class Emp {
	
	private int employeeId;
	
	private String empName;
	
	private java.util.Date joinDate;
	
	private String designationCode;
	
	private String department;
	
	private double basic;
	
	private double hra;
	
	private double it;

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}



	public java.util.Date getJoinDate() {
		return joinDate;
	}

	public void setJoinDate(java.util.Date joinDate) {
		this.joinDate = joinDate;
	}

	public String getDesignationCode() {
		return designationCode;
	}

	public void setDesignationCode(String designationCode) {
		this.designationCode = designationCode;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public double getBasic() {
		return basic;
	}

	public void setBasic(double basic) {
		this.basic = basic;
	}

	public double getHra() {
		return hra;
	}

	public void setHra(double hra) {
		this.hra = hra;
	}



	public double getIt() {
		return it;
	}

	public void setIt(double it) {
		this.it = it;
	}



	public Emp(int employeeId, String empName, Date joinDate, String designationCode, String department, double basic,
			double hra, double it) {
		super();
		this.employeeId = employeeId;
		this.empName = empName;
		this.joinDate = joinDate;
		this.designationCode = designationCode;
		this.department = department;
		this.basic = basic;
		this.hra = hra;
		this.it = it;
	}

	public Emp() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Emp [employeeId=" + employeeId + ", empName=" + empName + ", joinDate=" + joinDate
				+ ", designationCode=" + designationCode + ", department=" + department + ", basic=" + basic + ", hra="
				+ hra + ", it=" + it + "]";
	}


	
	

}
