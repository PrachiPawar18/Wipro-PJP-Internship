package co.prachi;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Employee {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		Emp emp = new Emp();
		emp.setEmployeeId(1001);
		emp.setEmpName("Ashish");
		emp.setJoinDate(null);
		emp.setDesignationCode("e");
		emp.setDepartment("R&D");
		emp.setBasic(20000);
		emp.setHra(8000);
		emp.setIt(3000);

		Emp emp1 = new Emp();
		emp1.setEmployeeId(1002);
		emp1.setEmpName("Sushma");
		emp1.setJoinDate(null);
		emp1.setDesignationCode("c");
		emp1.setDepartment("PM");
		emp1.setBasic(30000);
		emp1.setHra(8000);
		emp1.setIt(9000);

		Emp emp2 = new Emp();
		emp2.setEmployeeId(1003);
		emp2.setEmpName("Rahul");
		emp2.setJoinDate(null);
		emp2.setDesignationCode("k");
		emp2.setDepartment("Acct");
		emp2.setBasic(10000);
		emp2.setHra(8000);
		emp2.setIt(1000);

		Emp emp3 = new Emp();
		emp3.setEmployeeId(1004);
		emp3.setEmpName("Chahat");
		emp3.setJoinDate(null);
		emp3.setDesignationCode("r");
		emp3.setDepartment("Front desk");
		emp3.setBasic(12000);
		emp3.setHra(6000);
		emp3.setIt(2000);

		Emp emp4 = new Emp();
		emp4.setEmployeeId(1005);
		emp4.setEmpName("Ranjan");
		emp4.setJoinDate(null);
		emp4.setDesignationCode("m");
		emp4.setDepartment("Engg");
		emp4.setBasic(50000);
		emp4.setHra(20000);
		emp4.setIt(20000);

		Emp emp5 = new Emp();
		emp5.setEmployeeId(1006);
		emp5.setEmpName("Suman");
		emp5.setJoinDate(null);
		emp5.setDesignationCode("e");
		emp5.setDepartment("manufacturing");
		emp5.setBasic(23000);
		emp5.setHra(9000);
		emp5.setIt(4400);

		Emp emp6 = new Emp();
		emp6.setEmployeeId(1007);
		emp6.setEmpName("Tanmany");
		emp6.setJoinDate(null);
		emp6.setDesignationCode("c");
		emp6.setDepartment("PM");
		emp6.setBasic(29000);
		emp6.setHra(12000);
		emp6.setIt(10000);

		List<Emp> emps = new ArrayList<Emp>();
		emps.add(emp);
		emps.add(emp1);
		emps.add(emp2);
		emps.add(emp3);
		emps.add(emp4);
		emps.add(emp5);
		emps.add(emp6);

		int empId = 0;
		double salary = 0;
		double da = 0;
		System.out.println("Enter Emp Id:");
		empId = sc.nextInt();

		for (Emp e : emps) {

			if(e.getEmployeeId()==empId) {
			
			System.out.println(e);
			String desig = null;
		
				switch (e.getDesignationCode()) {
				case "e":
					desig="Engineer";
					//System.out.println("Engineer");
					da = 20000;
					break;

				case "c":
					desig="Consultant";
					//System.out.println("Consultant");
					da = 32000;
					break;

				case "k":
					desig="Cleark";
				//	System.out.println("Cleark");
					da = 12000;
					break;

				case "r":
					desig="Receptionist";
				//	System.out.println("Receptionist");
					da = 15000;
					break;

				case "m":
					desig="Manager";
					//System.out.println("Manager");
					da = 40000;
					break;

				}
			//	System.out.println(emp.getBasic());
				salary = e.getBasic() + e.getHra() + da - (e.getIt());
				System.out.println(" EmpNo: "+e.getEmployeeId()+" Name: "+e.getEmpName()+" Department: "+e.getDepartment()+" Designation: "+desig+" Salary: "+salary);

			} else {
				System.out.println("There is no employee with empId:" + empId);
				break;
			}
		}

	}

}
