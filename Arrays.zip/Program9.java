package assignment_3;

import java.util.Scanner;

public class Program9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]=new int[100];       
		 Scanner sc=new Scanner(System.in);       
		 System.out.println("no of elements");      
		  int n=sc.nextInt();       
		 for(int i=0;i<n;i++) arr[i]=sc.nextInt();       
		 sc.close();      
		  int left=6,right=7;       
		 int lindex=-1,rindex=-1;      
		  for(int i=0;i<arr.length;i++) {       
		     if(arr[i]==left) lindex=i;           
		 if(arr[i]==right) rindex=i;      
		  }     
		   int sum=0;      
		  if(lindex<rindex)        {         
		   for(int i=lindex;i<=rindex;i++) {           
		     arr[i]=0;       
		     }          
		  for(int i:arr) sum+=i;     
		   }else{   
		         for(int i:arr) {      
		          sum+=i;      
		      }      
		  }      
		  System.out.println(sum);  
	}

}
