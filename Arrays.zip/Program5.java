package assignment_3;

public class Program5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int[] arr={-5,21,64,9,4325,43,999,34,55,98};  
		  int flarge=Integer.MIN_VALUE,slarge=Integer.MIN_VALUE;    
		  int fsmall=Integer.MAX_VALUE,ssmall=Integer.MAX_VALUE;       
		  for(int i:arr) if(i>flarge) flarge=i;       
		  for(int i:arr) if(i>slarge && i!=flarge) slarge=i;       
		  for(int i:arr) if(i<fsmall) fsmall=i;     
		  for(int i:arr) if(i<ssmall && i!=fsmall) ssmall=i;   
		  System.out.println("first large = "+flarge);      
		  System.out.println("second large = "+slarge);       
		  System.out.println("first small = "+fsmall);     
		  System.out.println("second small = "+ssmall); 
	
	}

}
