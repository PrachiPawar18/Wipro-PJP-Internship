package assignment_3;

public class Program4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr={66,67,101,98,99,100,113};     
		 for(int c:arr) System.out.println((char)c);
	}

}
