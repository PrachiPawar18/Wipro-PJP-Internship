package assignment_3;

import java.util.Scanner;

public class Program3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		System.out.println("enter number of elements you want:\n");
		int n=in.nextInt();
		
		int arr[]=new int[n];
		System.out.println("enter elements of an array:\n");
		for(int i=0;i<n;i++) {
			arr[i]=in.nextInt();
		}
		System.out.println("enter number you want to search:\n");
		int a=in.nextInt();
		int flag=-1;
		for(int i=0;i<arr.length;i++) {
			if(a==arr[i]) {
				flag=i;
				
			}
		}
		if(flag==-1) {
			System.out.println("-1");
		}
		else {
			System.out.println(flag);
		}
		in.close();
	}

}
