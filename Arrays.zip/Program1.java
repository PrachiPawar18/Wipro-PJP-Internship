package assignment_3;

import java.util.Scanner;

public class Program1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum=0,avg=0;
		System.out.println("enter the number of elements:\n");
		Scanner sc = new Scanner(System.in);
		int n=sc.nextInt();
		

		int[] array=new int[100];
		System.out.println("enter elements of array:\n");
		for(int i=0;i<n;i++) {
			array[i]=sc.nextInt();
		}
	    for(int i = 0; i < n; i++) {										
			sum = sum + array[i];
			avg=(sum/n);
		}
	    sc.close();
		System.out.println("The sum of the array is: "+sum);
												
		System.out.println("The average of the array is: "+avg);
	}

}
