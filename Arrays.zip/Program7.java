package assignment_3;

import java.util.Arrays;

public class Program7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int[] arr={4,5,9,11,4,48,82,0}; 
		  Arrays.sort(arr);      
		  for(int i:arr)System.out.print(i+" ");
		   System.out.println();
	}

}
