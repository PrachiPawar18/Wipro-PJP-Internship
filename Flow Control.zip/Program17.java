package assignment_2;

import java.util.Scanner;

public class Program17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("enter no:");
		int x= sc.nextInt();
		int rev=0;
		while(x!=0) {
			int remainder=x%10;
			rev=rev*10 + remainder;
			x=x/10;
				
		}
		System.out.println("The reverse number of given number is:"+rev);
		sc.close();
	}

}
