package assignment_2;

import java.util.Scanner;

public class Program15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x,sum;
		Scanner sc= new Scanner(System.in);
		System.out.println("enter no:");
	    x= sc.nextInt();


		sc.close();
		for(sum=0;x!=0;x=x/10) {
			sum=sum+x%10;
		}
		
		
		System.out.println("sum of digits in given number is "+sum);
		
		sc.close();
	}

}
