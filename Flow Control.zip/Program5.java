package assignment_2;

public class Program5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 char c='#';      
		 if((c>='a' && c<='z') || (c>='A' && c<='Z') ) {
			 System.out.println("Alphabet");     
		 }
		  else if(Character.isDigit(c)) {
			  System.out.println("Digit");   
		  }
		    else {
		    	System.out.println("Special char");
		    }
	}
}