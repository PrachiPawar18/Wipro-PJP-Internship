package assignment_2;

import java.util.Scanner;

public class Program20 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter option number that you want to select\n");
		System.out.println("1. Add\n2. Sub\n3. Mul\n4. Div\n");
		int choice = sc.nextInt();
		
		int operand1;
		int operand2;
		int result;
		
		if (choice == 1) {
			System.out.println("Enter first number: ");
			operand1 = sc.nextInt();
			System.out.println("Enter second number: ");
			operand2 = sc.nextInt();
			result = operand1 + operand2;
		} else if (choice==2) {
			System.out.println("Enter first number: ");
			operand1 = sc.nextInt();
			System.out.println("Enter second number: ");
			operand2 = sc.nextInt();
			result = operand1 - operand2;
		}else if (choice==3) {
			System.out.println("Enter first number: ");
			operand1 = sc.nextInt();
			System.out.println("Enter second number: ");
			operand2 = sc.nextInt();
			result = operand1 * operand2;
		}else {
			System.out.println("Enter first number: ");
			operand1 = sc.nextInt();
			System.out.println("Enter second number: ");
			operand2 = sc.nextInt();
			result = operand1 / operand2;
			
		}
		
		System.out.println("Result: " + result);
		
		System.out.println(" Do you want to continue?\n Y or N");
		
		sc.nextLine();		
		choice = sc.nextLine().charAt(0);
		
		if (choice == 'Y' || choice == 'y') main(args);
		
		sc.close();
	}

}
