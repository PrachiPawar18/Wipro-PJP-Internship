package assignment_2;

public class Program13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j,temp;
		for(i=10;i<=99;i++) {
			temp=0;
			for(j=2;j<i;j++) {
				if(i%j==0) {
					temp=1;
					break;
				}
			}
			if(temp==0) {
				System.out.println(i);
			}
			
		}

	

	}

}
