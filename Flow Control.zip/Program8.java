package assignment_2;
import java.util.Scanner;
public class Program8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("enter first alphabet of colour that you want to print:");
		char colour=sc.next().charAt(0);
		switch(colour) {
		
		case 'R':
			System.out.println("Red");
			break;
		case 'B':
			System.out.println("Blue");
			break;
		case 'G':
			System.out.println("Green");
			break;
		case 'O':
			System.out.println("Orange");
			break;
		case 'Y':
			System.out.println("Yellow");
			break;
		case 'W':
			System.out.println("White");
			break;
		default:
			System.out.println("Colour code not valid");
		}
		sc.close();

	}

}
