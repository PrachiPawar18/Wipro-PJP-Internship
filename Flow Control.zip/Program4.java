package assignment_2;

public class Program4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char c1='a';    
		char c2='e';      
		if(c1>c2) { System.out.println(c2+","+c1);    
		}else {
			System.out.println(c1+","+c2);
		}
	}

}
