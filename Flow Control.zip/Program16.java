package assignment_2;

import java.util.Scanner;

public class Program16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n,i,j;
		System.out.println("enetr number: ");
		Scanner sc= new Scanner(System.in);
		n=sc.nextInt();
		for(i=0;i<n;i++) {
			for(j=0;j<=i;j++) {
				System.out.print("*");
			}
			System.out.println();
		}}}

