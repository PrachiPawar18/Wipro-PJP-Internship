package assignment_2;



public class Program7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char c='A';   
		   if(Character.isLowerCase(c)) {
		   System.out.println(Character.toUpperCase(c));   
		   }else {
			   System.out.println(Character.toLowerCase(c));
	}

}
}
