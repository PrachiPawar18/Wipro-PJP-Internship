package assignment_2;

import java.util.Scanner;

public class Program1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("enter no:");
		int x= sc.nextInt();
		if(x>0) {
			System.out.println("positive");
		}else if(x<0) {
			System.out.println("negative");
			
		}else {
			System.out.println("zero");
		}
		sc.close();
	}


	}







