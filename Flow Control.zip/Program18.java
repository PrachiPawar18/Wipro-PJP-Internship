package assignment_2;

import java.util.Scanner;

public class Program18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("enter no:");
		int x= sc.nextInt();
		int rev=0,s;
		s=x;
		while(x!=0) {
			int remainder=x%10;
			rev=rev*10 + remainder;
			x=x/10;

}
		if(s==rev) {
			System.out.println("Palindrome");
			
		}else {
			System.out.println("Not Palindrome");
		}
		sc.close();

	}

}
