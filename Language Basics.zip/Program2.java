package assignment_1;

public class Program2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(" Welcome " +args[0]);
	}

}
