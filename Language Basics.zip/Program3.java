package assignment_1;

public class Program3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a= Integer.parseInt(args[0]);
		int b= Integer.parseInt(args[1]);
		int sum=a+b;
		
		System.out.println("The sum of "+a +" and " +b +" is " +sum);
	}

}
