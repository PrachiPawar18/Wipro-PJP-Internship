package videorentalinventarysystem;

public class Video {
	String name;
	
	 boolean checkOut;
	
	 int rating;

	 
	 Video(String name)
	 {
		 
	 }


	public Video() {
		super();
		// TODO Auto-generated constructor stub
	}



	
	public String getName() {
		return name;
	}
	public void doCheck()
	{
		
	}
	public void doReturn()
	{
		
	}
	public void receiveRating()
	{
		
	}
	public int getRating()
	{
		return 0;
	}
	public boolean getCheckout()
	{
		return true;
	}


	public boolean isCheckOut() {
		return checkOut;
	}


	public void setCheckOut(boolean checkOut) {
		this.checkOut = checkOut;
	}


	public void setName(String name) {
		this.name = name;
	}


	public void setRating(int rating) {
		this.rating = rating;
	}


	@Override
	public String toString() {
		return "Video [name=" + name + ", checkOut=" + checkOut + ", rating=" + rating + "]";
	}
	
	

}
