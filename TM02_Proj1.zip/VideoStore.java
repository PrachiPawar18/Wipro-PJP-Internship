package videorentalinventarysystem;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class VideoStore {
	
	// private Video[] store;
		List<Video> list = new ArrayList<Video>();
		Scanner sc = new Scanner(System.in);

		void addVideo(Video video) {
//			System.out.println("Enter Video name:");
//			String name=sc.next();
//			video.setName(name);
//			System.out.println(video);
			list.add(video);

		}

		void doCheckout(String name) {
			// Video video = new Video();
			boolean status = false;

			for (Video v : list) {

				// System.out.println(v.getName());

				if (v.getName().equals(name)) {
					status = true;
				} else {
					status = false;
				}
				v.setCheckOut(status);
				System.out.println(v);
			}
			System.out.println(status+ " Your video checkout successfully ");
			
		}

		void doReturn(String name) {
			boolean status =false;

			for (Video v : list) {

				if (v.getName().equals(name)) {
					status = false;
				} else {
					status = true;
				}
				v.setCheckOut(status);
				System.out.println(v);
			}
			System.out.println(status);
		}

		void recieveRating(String name, int rating) {
			//boolean status = false;

			for (Video v : list) {

				// System.out.println(v.getName());

				if (v.getName().equals(name)) {
					v.setRating(rating);
					System.out.println("rating submitted successfully");
					//status = true;
				} else {
					System.out.println("video not found");
				}
				//v.setCheckOut(status);
				System.out.println(v);
			}
			//System.out.println(status);
			
		}

		void listInventory() {
			
			for (Video v : list) {
					System.out.println(v);
			}

		}


}
