package videorentalinventarysystem;

import java.util.Scanner;
public class VideoLauncher {

public static void main(String[] args) {
		
		VideoStore out=new VideoStore(); 
		Scanner sc=new Scanner(System.in);
		Video video=new Video();
		

		System.out.println("####WELCOME TO VIDEO GALLARY####");

		int ch;
		

		do {
			System.out.println(
					"Enter your choice\n1.Add videos\n2.CheckOut Videos\n3.Return Videos\n4.Receive rating\n5.List Inventory\n0.Exit");
			Scanner scanner = new Scanner(System.in);
			 ch = scanner.nextInt();
			// String name;
		//	 int rating;

		switch (ch) {
					case 1:
						
						//System.out.println("Enter video name:");
						System.out.println("Enter Video name:");
						String name=sc.next();
						video.setName(name);
				
						System.out.println(video);
						out.addVideo(video);
						break;
					
					case 2:
						System.out.println("Enter the video name you want to checkout...");
						String name1=sc.next();
						out.doCheckout(name1);
						
						break;
						
					case 3:
						System.out.println("Enter the video name you want to Return...");
						String name2=sc.next();
						out.doReturn(name2);
						break;
						
					case 4:
						System.out.println("Enter the video name you want to rating");
						String name3=sc.next();
						System.out.println("Enter the rating to this video");
						int rating=sc.nextInt();
						out.recieveRating(name3, rating);
						break;
						
					case 5:
						out.listInventory();
						break;
						
					case 0:
						System.out.println("Thank you for using this app....");
						break;
		}
		}while(ch!=0);

	}

}
